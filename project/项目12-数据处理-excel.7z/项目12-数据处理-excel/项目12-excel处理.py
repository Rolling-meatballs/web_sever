import openpyxl

'''
本项目需要使用 openpyxl 处理 excel 文件
注意，只支持 xlsx 格式，不支持 xls 格式

需要用 pip 安装 openpyxl 库

本项目和项目 11 是一样的，不同之处在于本次要处理和生成的是 excel 文件而不是 csv 文件
参考下面的例子代码，实现对 12-list.xlsx 的处理，这个文件在群文件中
处理要求同项目 11 一样


openpyxl 的官方文档（本次项目没有看的必要）:
http://openpyxl.readthedocs.io/en/stable/
'''

log = print


def write():
    # 创建一个新的工作表簿
    workbook = openpyxl.Workbook()
    # 获取表格的默认工作表
    sheet = workbook.active
    # 设置工作表的凑题
    sheet.title = '新标题'
    # 在 C栏 的第一行写入数据
    sheet['C1'] = 'hello python'
    # 在 A栏 中写入数据
    for i in range(10):
        s = 'A{}'.format(i + 1)
        sheet[s].value = i + 1
    # 保存到 demo.xlsx 文件中
    workbook.save('demo.xlsx')


def read():
    filename = '12-list.xlsx'
    workbook = openpyxl.load_workbook(filename)
    # 所有的工作表单名字
    log(workbook.sheetnames)
    # 拿到某个 工作表 内容的标准做法，我们这个 excel 文件只有一个 city 工作表
    sheet = workbook['city']
    # sheet['C1'].value     # 返回 C 列第 1 行格子里的值
    # sheet['1']            # 第一行的所有格子(返回一个 tuple)
    # sheet.max_column      # 最大列数
    # sheet.max_row         # 最大行数

    # 用 .value 获取格子里的值
    log('sheet c1 value', sheet['C1'].value)
    log('max row', sheet.max_row)
    # 获取一行
    log('row', sheet['2'])
    # 遍历第二行所有格子
    for c in sheet['2']:
        log('格子', c.value)
    # # 遍历获取 A 列所有的值
    # for a in sheet['A']:
    #     log('a', a.value)


def main():
    read()
    # write()


if __name__ == '__main__':
    main()
